/*
Jared Holzmeyer
Dr. Morse
CS315
4/11/2019
Assignment 2
maxpath.h
*/

#ifndef MAXPATH_H
#define MAXPATH_H

int maxPathTotal(int depth, int* triangle);

#endif
